%% car-car-car
clc;clear;
dbstop if error
data1 = csvread('D:\project\HighD\14\two-car\car-car-car.csv',2,1);
mainV1 = data1(1:15680,15);
preV1 = data1(1:15680,4);
mainX1 = data1(1:15680,13);
preX1 = data1(1:15680,2);
thw1 = data1(1:15680,17);
L1 = data1(1:15680,3);
A1 = data1(1:15680,5);
deltv1 = mainV1 - preV1;
S1 = preX1 - mainX1 - L1;
TTC1 = data1(1:15680,18);
TTC1d = TTC1.^-1;
meanV1 = mean(mainV1)
meanTTC1d = mean(TTC1d)




%% 速度图
pic1 = figure(1);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小

[counts,centers] = hist(mainV1,45);
pic1 = bar(centers,counts/sum(counts),1);
set(pic1,'FaceColor','b');
set(gca,'xtick',20:5:45)    
set(gca,'xlim',[20 45]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}速度\fontname{Times new roman}{{\it{v}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}两辆前车速度均值=\fontname{Times new roman}{31.8425 (m/s)}'],'fontsize',fontsize_label); % 横坐标
% title('两辆前车(速度均值=31.8425 m/s)','fontsize',fontsize_label); 


%% 相对速度图

pic2 = figure(2);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小

[counts,centers] = hist(deltv1,45);
pic2 = bar(centers,counts/sum(counts),1);
set(pic2,'FaceColor','b');
set(gca,'xtick',-10:5:10)    
set(gca,'xlim',[-10 10]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}相对速度\fontname{Times new roman}{{\it{dv}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}两辆前车相对速度均值=\fontname{Times new roman}{-0.3430 (m/s)}'],'fontsize',fontsize_label); % 横坐标


%% 加速度图

pic5 = figure(5);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小


[counts,centers] = hist(A1,30);
pic5 = bar(centers,counts/sum(counts),1);
set(pic5,'FaceColor','b');
set(gca,'xtick',-1:0.5:1)    
set(gca,'xlim',[-1 1]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}加速度\fontname{Times new roman}{{\it{a}}(m/s^{−2})}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}两辆前车加速度均值=\fontname{Times new roman}{0.1387 (m/s^{−2})}'],'fontsize',fontsize_label); % 横坐标
 


%% 车间距图

pic3 = figure(3);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小

[counts,centers] = hist(S1,45);
pic3 = bar(centers,counts/sum(counts),1);
set(pic3,'FaceColor','b');
set(gca,'xtick',0:50:200)    
set(gca,'xlim',[0 200]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}车间距\fontname{Times new roman}{{\it{S}}(m)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}两辆前车车间距均值=\fontname{Times new roman}{57.7874 (m)}'],'fontsize',fontsize_label); % 横坐标



%% 车头时距


pic4 = figure(4);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小



[counts,centers] = hist(thw1,40);
pic4 = bar(centers,counts/sum(counts),1);
set(pic4,'FaceColor','b');
set(gca,'xtick',0:1:7)    
set(gca,'xlim',[0 7]);
set(gca,'ytick',0:0.02:0.1)    
set(gca,'ylim',[0 0.1]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}车头时距\fontname{Times new roman}{{\it{THW}}(s)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}两辆前车车头时距均值=\fontname{Times new roman}{1.8065 (s)}'],'fontsize',fontsize_label); % 横坐标

%% 逆碰撞时间

pic6 = figure(18);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小



[counts,centers] = hist(TTC1d,50);
pic1 = bar(centers,counts/sum(counts),1);
set(pic1,'FaceColor','b');
set(gca,'xtick',-0.2:0.1:0.2)    
set(gca,'xlim',[-0.2 0.2]);
set(gca,'ytick',0:0.05:0.15)    
set(gca,'ylim',[0 0.15]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}逆碰撞时间\fontname{Times new roman}{{\it{1/TTC}}(s)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}两辆前车逆碰撞时间=\fontname{Times new roman}{-0.0039 (s)}'],'fontsize',fontsize_label); % 横坐标














%% 相对速度-车间距


X1 = deltv1;
Y1 = S1;
[Xsorted1,I] = sort(X1);
Ysorted1 = Y1(I);
min_deltv1 = min(Xsorted1);
max_deltv1 = max(Xsorted1);
x1 = linspace(min_deltv1,max_deltv1,50);
q1 = zeros(50,3);
for i= 1:length(x1)
     q1(i,1) = x1(i);
end
for i=1:length(Xsorted1)
    for j=1:length(q1)
        if Xsorted1(i) >= q1(j,1) && Xsorted1(i) <= q1(j+1,1)
            q1(j,2)= q1(j,2)+Ysorted1(i);
            q1(j,3)= q1(j,3)+1;
            break
        end
    end
end
figure(9);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
X1 = q1(9:38,1);
Y1 = q1(9:38,2)./q1(9:38,3);
bar(X1,Y1,'b');
set(gca,'xtick',-6:2:6)    
set(gca,'xlim',[-6 6]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');

xlabel(['\fontname{宋体}相对速度\fontname{Times new roman}{{\it{dv}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}车间距\fontname{Times new roman}{{\it{S}}(m)}'],'fontsize',fontsize_label); % 纵坐标


%% 相对速度-加速度

X3 = deltv1;
Y3 = A1;
[Xsorted1,I] = sort(X3);
Ysorted1 = Y3(I);
min_deltv1 = min(Xsorted1);
max_deltv1 = max(Xsorted1);
x1 = linspace(min_deltv1,max_deltv1,50);
q1 = zeros(50,3);
for i= 1:length(x1)
    q1(i,1) = x1(i);
end
for i=1:length(Xsorted1)
    for j=1:length(q1)
        if Xsorted1(i) >= q1(j,1) && Xsorted1(i) <= q1(j+1,1)
            q1(j,2)= q1(j,2)+Ysorted1(i);
            q1(j,3)= q1(j,3)+1;
            break
        end
    end
end
figure(10);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
X3 = q1(8:40,1);
Y3 = q1(8:40,2)./q1(8:40,3);
bar(X3,Y3,'b');
set(gca,'xtick',-6:2:6)    
set(gca,'xlim',[-6 6]);
set(gca,'ytick',-0.6:0.2:0.4)    
set(gca,'ylim',[-0.6 0.4]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}相对速度\fontname{Times new roman}{{\it{dv}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}加速度\fontname{Times new roman}{{\it{a}}(m/s^{−2})}'],'fontsize',fontsize_label); % 纵坐标




%% 速度-车间距
XX1 = mainV1;
YY1 = S1;
[XX1sorted,I] = sort(XX1);
YY1sorted = YY1(I);
min_deltv = min(XX1sorted);
max_deltv = max(XX1sorted);
xx1 = linspace(min_deltv,max_deltv,50);
qq1 = zeros(50,3);
for i= 1:length(xx1)
    qq1(i,1) = xx1(i);
end
for i=1:length(XX1sorted)
    for j=1:length(qq1)
        if XX1sorted(i) >= qq1(j,1) && XX1sorted(i) <= qq1(j+1,1)
            qq1(j,2)= qq1(j,2)+YY1sorted(i);
            qq1(j,3)= qq1(j,3)+1;
            break
        end
    end
end
figure(12);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
XX1 = qq1(1:49,1);
YY1 = qq1(1:49,2)./qq1(1:49,3);
bar(XX1,YY1,'b');
set(gca,'xtick',20:5:40)    
set(gca,'xlim',[20 40]);
set(gca,'ytick',0:50:100)    
set(gca,'ylim',[0 100]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}速度\fontname{Times new roman}{{\it{v}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}车间距\fontname{Times new roman}{{\it{S}}(m)}'],'fontsize',fontsize_label); % 纵坐标







%% car-car
data2 = csvread('D:\project\HighD\14\one-car\car-car.csv',2,1);
mainV2 = data2(1:15487,15);
preV2 = data2(1:15487,4);
mainX2 = data2(1:15487,13);
preX2 = data2(1:15487,2);
thw2 = data2(1:15487,17);
L2 = data2(1:15487,3);
A2 = data2(1:15487,5);
deltv2 = mainV2 - preV2;
S2 = preX2 - mainX2 - L2;
TTC2 = data2(1:15487,18);
TTC2d = TTC2.^-1;
meanV2 = mean(mainV2)
meanTTC2d = mean(TTC2d)

%% 速度图

pic1 = figure(13);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小

[counts,centers] = hist(mainV2,55);
pic1 = bar(centers,counts/sum(counts),1);
set(pic1,'FaceColor','r');
set(gca,'xtick',20:5:45)    
set(gca,'xlim',[20 45]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}速度\fontname{Times new roman}{{\it{v}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}一辆前车速度均值=\fontname{Times new roman}{32.1415 (m/s)}'],'fontsize',fontsize_label); % 横坐标



%% 相对速度图
pic2 = figure(14);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
[counts,centers] = hist(deltv2,45);
pic2 = bar(centers,counts/sum(counts),1);
set(pic2,'FaceColor','r');
set(gca,'xtick',-10:5:10)    
set(gca,'xlim',[-10 10]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}相对速度\fontname{Times new roman}{{\it{dv}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}一辆前车相对速度均值=\fontname{Times new roman}{-0.5102 (m/s)}'],'fontsize',fontsize_label); % 横坐标




%% 加速度图

pic5 = figure(17);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
[counts,centers] = hist(A2,30);
pic5 = bar(centers,counts/sum(counts),1);
set(pic5,'FaceColor','r');
set(gca,'xtick',-1:0.5:1)    
set(gca,'xlim',[-1 1]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}加速度\fontname{Times new roman}{{\it{a}}(m/s^{−2})}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}一辆前车加速度均值=\fontname{Times new roman}{0.2173 (m/s^{−2})}'],'fontsize',fontsize_label); % 横坐标



% 
% 
% 
% 
%% 车间距

pic3 = figure(15);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
[counts,centers] = hist(S2,50);
pic3 = bar(centers,counts/sum(counts),1);
set(pic3,'FaceColor','r');
set(gca,'xtick',0:50:200)    
set(gca,'xlim',[0 200]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}车间距\fontname{Times new roman}{{\it{S}}(m)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}一辆前车车间距均值=\fontname{Times new roman}{67.1607 (m)}'],'fontsize',fontsize_label); % 横坐标
 



%% 车头时距

pic4 = figure(16);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小

[counts,centers] = hist(thw2,40);
pic4 = bar(centers,counts/sum(counts),1);
set(gca,'xtick',0:1:7)    
set(gca,'xlim',[0 7]);
set(gca,'ytick',0:0.02:0.1)    
set(gca,'ylim',[0 0.1]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
set(pic4,'FaceColor','r');
xlabel(['\fontname{宋体}车头时距\fontname{Times new roman}{{\it{THW}}(s)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}一辆前车车头时距均值=\fontname{Times new roman}{2.0767 (s)}'],'fontsize',fontsize_label); % 横坐标


%% 逆碰撞时间

pic6 = figure(18);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小






[counts,centers] = hist(TTC2d,50);
pic6 = bar(centers,counts/sum(counts),1);
set(pic6,'FaceColor','r');
set(gca,'xtick',-0.2:0.1:0.2)    
set(gca,'xlim',[-0.2 0.2]);
set(gca,'ytick',0:0.05:0.15)    
set(gca,'ylim',[0 0.15]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');

xlabel(['\fontname{宋体}逆碰撞时间\fontname{Times new roman}{{\it{1/TTC}}(s)}'],'fontsize',fontsize_label); % 横坐标
ylabel('\fontname{宋体}频率','fontsize',fontsize_label); % 横坐标
title(['\fontname{宋体}一辆前车逆碰撞时间=\fontname{Times new roman}{-0.0060 (s)}'],'fontsize',fontsize_label); % 横坐标











%% 相对速度-车间距

X2 = deltv2;
Y2 = S2;
[Xsorted2,I] = sort(X2);
Ysorted2 = Y2(I);
min_deltv2 = min(Xsorted2);
max_deltv2 = max(Xsorted2);
x2 = linspace(min_deltv2,max_deltv2,50);
q2 = zeros(50,3);
for i= 1:length(x2)
    q2(i,1) = x2(i);
end
for i=1:length(Xsorted2)
    for j=1:length(q2)
        if Xsorted2(i) >= q2(j,1) && Xsorted2(i) <= q2(j+1,1)
            q2(j,2)= q2(j,2)+Ysorted2(i);
            q2(j,3)= q2(j,3)+1;
            break
        end
    end
end
figure(21);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
X2 = q2(12:41,1);
Y2 = q2(12:41,2)./q2(12:41,3);
bar(X2,Y2,'r');
set(gca,'xtick',-6:2:6)    
set(gca,'xlim',[-6 6]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}相对速度\fontname{Times new roman}{{\it{dv}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}车间距\fontname{Times new roman}{{\it{S}}(m)}'],'fontsize',fontsize_label); % 纵坐标

% 
% 
%% 相对速度-加速度

XX3 = deltv2;
YY3 = A2;
[Xsorted1,I] = sort(XX3);
Ysorted1 = YY3(I);
min_deltv1 = min(Xsorted1);
max_deltv1 = max(Xsorted1);
x1 = linspace(min_deltv1,max_deltv1,50);
q1 = zeros(50,3);
for i= 1:length(x1)
    q1(i,1) = x1(i);
end
for i=1:length(Xsorted1)
    for j=1:length(q1)
        if Xsorted1(i) >= q1(j,1) && Xsorted1(i) <= q1(j+1,1)
            q1(j,2)= q1(j,2)+Ysorted1(i);
            q1(j,3)= q1(j,3)+1;
            break
        end
    end
end
figure(22);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
XX3 = q1(10:42,1);
YY3 = q1(10:42,2)./q1(10:42,3);
bar(XX3,YY3,'r');
set(gca,'xtick',-6:2:6)    
set(gca,'xlim',[-6 6]);
set(gca,'ytick',-0.2:0.2:0.4)    
set(gca,'ylim',[-0.2 0.4]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}相对速度\fontname{Times new roman}{{\it{dv}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}加速度\fontname{Times new roman}{{\it{a}}(m/s^{−2})}'],'fontsize',fontsize_label); % 纵坐标
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
%% 速度-车间距

XX2 = mainV2;
YY2 = S2;
[XX2sorted,I] = sort(XX2);
YY2sorted = YY2(I);
min_mainV = min(XX2sorted);
max_mainV = max(XX2sorted);
xx2 = linspace(min_mainV,max_mainV,50);
qq2 = zeros(50,3);
for i= 1:length(xx2)
    qq2(i,1) = xx2(i);
end
for i=1:length(XX2sorted)
    for j=1:length(qq2)
        if XX2sorted(i) >= qq2(j,1) && XX2sorted(i) <= qq2(j+1,1)
            qq2(j,2)= qq2(j,2)+YY2sorted(i);
            qq2(j,3)= qq2(j,3)+1;
            break
        end
    end
end
figure(24);
set(gcf,'unit','centimeters','position',[10,10,7.5,5.5])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
XX2 = qq2(1:43,1);
YY2 = qq2(1:43,2)./qq2(1:43,3);
bar(XX2,YY2,'r');
set(gca,'xtick',20:5:40)    
set(gca,'xlim',[20 40]);
set(gca,'ytick',0:50:100)    
set(gca,'ylim',[0 100]);
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}速度\fontname{Times new roman}{{\it{v}}(m/s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}车间距\fontname{Times new roman}{{\it{S}}(m)}'],'fontsize',fontsize_label); % 纵坐标