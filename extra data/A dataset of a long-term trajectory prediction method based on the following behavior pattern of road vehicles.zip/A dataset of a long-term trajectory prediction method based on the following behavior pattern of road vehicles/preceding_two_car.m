%%HighD数据集跟车工况
clc;clear;
dbstop if error
%%数据导入
data = csvread('E:\桌面\大论文仿真图\前方有两辆车工况验证\工况一\1068-1073.csv',2,1);
pre_v = data(1:250,4);
pre_a = data(1:250,5);
pre_y = data(1:250,2);
pre_L = data(1:250,3);
main_v = data(1:250,15);
main_a = data(1:250,16);
main_y = data(1:250,13);
main_S = pre_y-main_y-pre_L;
pre_car = struct('a',{},'v',{},'y',{},'L',{});
for i = 1:length(pre_a)
    
    pre_car(i).a = pre_a(i);
    pre_car(i).v = pre_v(i);
    pre_car(i).y = pre_y(i);
    pre_car(i).L = pre_L(i);
end

%%----初始化跟驰车信息
main_car = struct('a',{},'v',{},'y',{});
main_car(1).a = 0.14;
main_car(1).v = 29.14;  %单位米每秒
main_car(1).y = 5.08;
for i = 2:length(pre_a)
    
    main_car(i).a = 0;
    main_car(i).v = 0;
    main_car(i).y = 0;
end
%基本参数设置
global IDM_a_max IDM_v_max IDM_d_safe IDM_T_safe IDM_b_max time_step
%%IDM模型参数
%%IDM模型参数
IDM_a_max = 0.7791;
IDM_v_max = 30.3307;
IDM_d_safe = 4.7935;     
IDM_b_max = 3.4131;
IDM_T_safe = 1.2965;
time_step = 0.04;% 单位仿真步长/s
%%SDVIDM模型参数
global SDVIDM_a_max SDVIDM_v_max SDVIDM_d_safe SDVIDM_T_safe SDVIDM_b_max 
SDVIDM_a_max = 1.0360;
SDVIDM_v_max = 31.2342;
SDVIDM_d_safe = 5.3203;    
SDVIDM_b_max = 3.6839;
SDVIDM_T_safe = 1.1557;
global SVIDM_a_max SVIDM_v_max SVIDM_d_safe SVIDM_T_safe SVIDM_b_max 
%%SVIDM模型参数
SVIDM_a_max = 1.0978;
SVIDM_v_max = 30.4095;
SVIDM_d_safe = 5.1585;     
SVIDM_b_max = 3.5511;
SVIDM_T_safe = 1.0203;

for i = 1:length(pre_car)
    %%ADV
        a4 = ADV_folow_vehicle_state_update(pre_car(i),main_car(i));  % 加速度
        [y,v] = update(a4,main_car(i));  % 位置、速度
        main_car(i+1).y = y;
        main_car(i+1).v = v;
        main_car(i+1).a = a4;
        pre_ylist =[pre_car.y];
        pre_vlist =[pre_car.v];
        pre_alist =[pre_car.a];
        pre_Llist =[pre_car.L];
        ADV_main_ylist = [main_car.y];
        ADV_main_vlist = [main_car.v];
        ADV_main_alist = [main_car.a];
        ADV_main_alist(1) = [];
        ADV_main_ylist(1) = [];
        ADV_main_vlist(1) = [];
end

ADV_RMSE_V = sqrt(mean((ADV_main_vlist-main_v').^2))
ADV_RMSE_A = sqrt(mean((ADV_main_alist-main_a').^2))
ADV_RMSE_Y = sqrt(mean((ADV_main_ylist-main_y').^2))
for i = 1:length(pre_car)
    %%SDVIDM
        a2 = SDVIDM_folow_vehicle_state_update(pre_car(i),main_car(i));
        [y,v] = update(a2,main_car(i));
        main_car(i+1).y = y;
        main_car(i+1).v = v;
        main_car(i+1).a = a2;
        SDVIDM_main_ylist = [main_car.y];
        SDVIDM_main_vlist = [main_car.v];
        SDVIDM_main_alist = [main_car.a];
        SDVIDM_main_alist(1) = [];
        SDVIDM_main_ylist(1) = [];
        SDVIDM_main_vlist(1) = [];
end

SDVIDM_RMSE_V = sqrt(mean((SDVIDM_main_vlist-main_v').^2))
SDVIDM_RMSE_A = sqrt(mean((SDVIDM_main_alist-main_a').^2))
SDVIDM_RMSE_Y = sqrt(mean((SDVIDM_main_ylist-main_y').^2))
for i = 1:length(pre_car)
    %%SVIDM
        a3 = SVIDM_folow_vehicle_state_update(pre_car(i),main_car(i));
        [y,v] = update(a3,main_car(i));
        main_car(i+1).y = y;
        main_car(i+1).v = v;
        main_car(i+1).a = a3;
        SVIDM_main_ylist = [main_car.y];
        SVIDM_main_vlist = [main_car.v];
        SVIDM_main_alist = [main_car.a];
        SVIDM_main_alist(1) = [];
        SVIDM_main_ylist(1) = [];
        SVIDM_main_vlist(1) = [];
end

SVIDM_RMSE_V = sqrt(mean((SVIDM_main_vlist-main_v').^2))
SVIDM_RMSE_A = sqrt(mean((SVIDM_main_alist-main_a').^2))
SVIDM_RMSE_Y = sqrt(mean((SVIDM_main_ylist-main_y').^2))
for i = 1:length(pre_car)
    %%IDM
        a1 = IDM_folow_vehicle_state_update(pre_car(i),main_car(i));
        [y,v] = update(a1,main_car(i));
        main_car(i+1).y = y;
        main_car(i+1).v = v;
        main_car(i+1).a = a1;
        IDM_main_ylist = [main_car.y];
        IDM_main_vlist = [main_car.v];
        IDM_main_alist = [main_car.a];
        IDM_main_alist(1) = [];
        IDM_main_ylist(1) = [];
        IDM_main_vlist(1) = [];
     
end

IDM_RMSE_V = sqrt(mean((IDM_main_vlist-main_v').^2))
IDM_RMSE_A = sqrt(mean((IDM_main_alist-main_a').^2))
IDM_RMSE_Y = sqrt(mean((IDM_main_ylist-main_y').^2))
t = 0:0.04:(length(main_v)-1)*0.04;

% 移动平均窗口大小
window_size = 21;

% 计算移动平均
main_a_smoothed = movmean(main_a,window_size);
main_v_smoothed = movmean(main_v,window_size);


%% A4通栏3图速度
figure(1)

set(gcf,'unit','centimeters','position',[10,10,10,8])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_line = 1.2;      % 图形线条宽度
markersize = 5;          % 图形标记点大小
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
fontsize_legend = 8;      % 图例字体大小
MarkerIndices = 1:20:length(t);

h1 = plot(t,IDM_main_vlist,'b-^','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第一条线
set(h1,'MarkerFaceColor',get(h1,'color'));
set(gca,'xtick',0:2:10)    
set(gca,'xlim',[0 10]);
hold on;
h2 = plot(t,ADV_main_vlist,'c-s','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第二条线
set(h2,'MarkerFaceColor',get(h2,'color'));
hold on;
h3 = plot(t,SVIDM_main_vlist,'g-o','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第三条线
set(h3,'MarkerFaceColor',get(h3,'color'));
hold on;
h4 = plot(t,SDVIDM_main_vlist,'m-d','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第四条线
set(h4,'MarkerFaceColor',get(h4,'color'));
hold on;
plot(t,main_v_smoothed,'-r','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices) % 绘制第五条线
str1='{\fontname{Times New Roman}IDM}';
str2='{\fontname{Times New Roman}ADV}';
str3='{\fontname{Times New Roman}SVIDM}';
str4='{\fontname{Times New Roman}SDVIDM}';
str5='{\fontname{宋体}真实数据}';
h = legend(str1,str2,str3,str4,str5);
set(h,'fontsize',fontsize_legend,'fontname','Times new roman');
set(h,'box','off');
% h = legend('IDM','ADV','SVIDM','SDVIDM','真实值');       % 图例
% set(h,'fontsize',fontsize_legend);
% set(h,'Orientation','horizon');
% set(h,'box','off');
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}时间\fontname{Times new roman}{{\it{t}}(s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}速度\fontname{Times new roman}{{\it{v}}(m/s)}'],'fontsize',fontsize_label); % 横坐标

% 设置输出保存图片的大小和格式
hfig = figure(1);
figWidth = 10;  % 设置图片宽度
figHeight = 8;  % 设置图片高度
set(hfig,'PaperUnits','centimeters'); % 图片尺寸所用单位
set(hfig,'PaperPosition',[0 0 figWidth figHeight]);
fileout = 'test1.'; % 输出图片的文件名
print(hfig,[fileout,'tif'],'-r600','-dtiff'); % 设置图片格式、分辨率



%% 加速度
figure(2)

set(gcf,'unit','centimeters','position',[10,10,10,8])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_line = 1.2;      % 图形线条宽度
markersize = 5;          % 图形标记点大小
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
fontsize_legend = 8;      % 图例字体大小
MarkerIndices = 1:20:length(t);



h1 = plot(t,IDM_main_alist,'b-^','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第一条线
set(h1,'MarkerFaceColor',get(h1,'color'));
set(gca,'xtick',0:2:10)    
set(gca,'xlim',[0 10]);
set(gca,'ytick',-2:0.5:1)    
set(gca,'ylim',[-2 1]);
hold on;
h2 = plot(t,ADV_main_alist,'c-s','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第二条线
set(h2,'MarkerFaceColor',get(h2,'color'));
hold on;
h3 = plot(t,SVIDM_main_alist,'g-o','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第三条线
set(h3,'MarkerFaceColor',get(h3,'color'));
hold on;
h4 = plot(t,SDVIDM_main_alist,'m-d','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第四条线
set(h4,'MarkerFaceColor',get(h4,'color'));
hold on;
plot(t,main_a_smoothed,'-r','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices) % 绘制第五条线
str1='{\fontname{Times New Roman}IDM}';
str2='{\fontname{Times New Roman}ADV}';
str3='{\fontname{Times New Roman}SVIDM}';
str4='{\fontname{Times New Roman}SDVIDM}';
str5='{\fontname{宋体}真实数据}';
h = legend(str1,str2,str3,str4,str5);
set(h,'fontsize',fontsize_legend,'fontname','Times new roman');
set(h,'box','off');
% h = legend('IDM','ADV','SVIDM','SDVIDM','真实值');       % 图例
% set(h,'fontsize',fontsize_legend);
% set(h,'Orientation','horizon');
% set(h,'box','off');
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}时间\fontname{Times new roman}{{\it{t}}(s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}加速度\fontname{Times new roman}{{\it{a}}(m/s^{2})}'],'fontsize',fontsize_label); % 横坐标

% 设置输出保存图片的大小和格式
hfig = figure(2);
figWidth = 10;  % 设置图片宽度
figHeight = 8;  % 设置图片高度
set(hfig,'PaperUnits','centimeters'); % 图片尺寸所用单位
set(hfig,'PaperPosition',[0 0 figWidth figHeight]);
fileout = 'test1.'; % 输出图片的文件名
print(hfig,[fileout,'tif'],'-r300','-dtiff'); % 设置图片格式、分辨率


%% 位置
figure(3)

set(gcf,'unit','centimeters','position',[10,10,10,8])    % 图形窗口在电脑屏幕上的位置和尺寸[左 下 宽 高]
linewidth_line = 1.2;      % 图形线条宽度
markersize = 5;          % 图形标记点大小
linewidth_gca = 1;      % 横纵坐标轴宽度
fontsize_gca = 10;           % 横纵坐标轴刻度字体大小
fontsize_label = 10;         % 横纵坐标轴字体大小
fontsize_legend = 8;      % 图例字体大小
MarkerIndices = 1:20:length(t);


h1 = plot(t,IDM_main_ylist,'b-^','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第一条线
set(h1,'MarkerFaceColor',get(h1,'color'));
set(gca,'xtick',0:2:10)    
set(gca,'xlim',[0 10]);
set(gca,'ytick',0:50:300)    
set(gca,'ylim',[0 300]);
hold on;
h2 = plot(t,ADV_main_ylist,'c-s','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第二条线
set(h2,'MarkerFaceColor',get(h2,'color'));
hold on;
h3 = plot(t,SVIDM_main_ylist,'g-o','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第三条线
set(h3,'MarkerFaceColor',get(h3,'color'));
hold on;
h4 = plot(t,SDVIDM_main_ylist,'m-d','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices); % 绘制第四条线
set(h4,'MarkerFaceColor',get(h4,'color'));
hold on;
plot(t,main_y,'-r','linewidth',linewidth_line,'markersize',markersize,'MarkerIndices',MarkerIndices) % 绘制第五条线
str1='{\fontname{Times New Roman}IDM}';
str2='{\fontname{Times New Roman}ADV}';
str3='{\fontname{Times New Roman}SVIDM}';
str4='{\fontname{Times New Roman}SDVIDM}';
str5='{\fontname{宋体}真实数据}';
h = legend(str1,str2,str3,str4,str5);
set(h,'fontsize',fontsize_legend,'fontname','Times new roman');
set(h,'box','off');
% h = legend('IDM','ADV','SVIDM','SDVIDM','真实值');       % 图例
% set(h,'fontsize',fontsize_legend);
% set(h,'Orientation','horizon');
% set(h,'box','off');
set(gca,'linewidth',linewidth_gca,'fontsize',fontsize_gca)
set(gca,'GridLineStyle','--');
xlabel(['\fontname{宋体}时间\fontname{Times new roman}{{\it{t}}(s)}'],'fontsize',fontsize_label); % 横坐标
ylabel(['\fontname{宋体}位置\fontname{Times new roman}{{\it{y}}(m)}'],'fontsize',fontsize_label); % 横坐标

% 设置输出保存图片的大小和格式
hfig = figure(3);
figWidth = 10;  % 设置图片宽度
figHeight = 8;  % 设置图片高度
set(hfig,'PaperUnits','centimeters'); % 图片尺寸所用单位
set(hfig,'PaperPosition',[0 0 figWidth figHeight]);
fileout = 'test1.'; % 输出图片的文件名
print(hfig,[fileout,'tif'],'-r300','-dtiff'); % 设置图片格式、分辨率




% figure(1);
% h=plot(t,IDM_main_vlist,'b-o','MarkerIndices',1:20:length(t),'MarkerSize',10,'lineWidth',1);
% set(h,'MarkerFaceColor',get(h,'color'));
% hold on
% plot(t,IDM_main_vlist,'b-^',t,ADV_main_vlist,'c-s',t,SVIDM_main_vlist,'g-+',t,SDVIDM_main_vlist,'m-o',t,main_v,'-r','lineWidth',1.5);
% hold on
% xlabel('时间/s');ylabel('速度m/s');
% ylabel(['\fontname{华文中宋}加速度\fontname{Times new roman}(g)'])
% legend({'IDM','ADV','SVIDM','SDVIDM','真实速度'},'FontSize',9,'FontName','宋体');
% set(gcf,'color','white');
% set(gca,'FontSize',9,'FontName','宋体')
% box off



% figure(2);
% plot(t,IDM_main_alist,'b-^',t,ADV_main_alist,'c-s',t,SVIDM_main_alist,'g-+',t,SDVIDM_main_alist,'m-o',t,main_a,'-r','lineWidth',1.5);
% xlabel('时间/s');ylabel('加速度m/s^2');
% legend({'IDM','ADV','SVIDM','SDVIDM','真实速度'},'FontSize',12);
% set(gcf,'color','white');
% set(gca,'FontSize',16)
% box off
% 
% 
% 
% figure(3);
% plot(t,IDM_main_ylist,'b-^',t,ADV_main_ylist,'c-s',t,SVIDM_main_ylist,'g-+',t,SDVIDM_main_ylist,'m-o',t,main_y,'-r','lineWidth',1.5);
% xlabel('时间 t/s');ylabel('位置/m');
% legend({'IDM','ADV','SVIDM','SDVIDM','真实速度'},'FontSize',12);
% set(gcf,'color','white');
% set(gca,'FontSize',16)
% box off



%%IDM模型
function a1 = IDM_folow_vehicle_state_update(pre_car,main_car)

global IDM_a_max IDM_v_max IDM_d_safe IDM_T_safe IDM_b_max

    delta_v = main_car.v - pre_car.v;
    delta_y = pre_car.y - main_car.y - pre_car.L;
    my_two_sqrt_accel_deceleration = 2 * sqrt(IDM_a_max * IDM_b_max);  
    S1 = main_car.v * IDM_T_safe;   
    S2 = main_car.v * delta_v / my_two_sqrt_accel_deceleration;   
    expected_x = IDM_d_safe + S1 + S2;
    a1 = IDM_a_max * (1 - power(main_car.v / IDM_v_max, 4) - power(expected_x / delta_y, 2));
end
%%SDVIDM模型
function a2 = SDVIDM_folow_vehicle_state_update(pre_car,main_car)

global SDVIDM_a_max SDVIDM_v_max SDVIDM_d_safe SDVIDM_T_safe SDVIDM_b_max

    delta_v = main_car.v - pre_car.v;
    delta_y = 2.2272 * power(delta_v,2)-5.0347 * delta_v + 51.3215;
    my_two_sqrt_accel_deceleration = 2 * sqrt(SDVIDM_a_max * SDVIDM_b_max);  
    S1 = main_car.v * SDVIDM_T_safe;   
    S2 = main_car.v * delta_v / my_two_sqrt_accel_deceleration;   
    expected_x = SDVIDM_d_safe + S1 + S2;
    a2 = SDVIDM_a_max * (1 - power( main_car.v / SDVIDM_v_max, 4) - power(expected_x / delta_y, 2));
end
%%SVIDM模型
function a3 = SVIDM_folow_vehicle_state_update(pre_car,main_car)

global SVIDM_a_max SVIDM_v_max SVIDM_d_safe SVIDM_T_safe SVIDM_b_max

    delta_v = main_car.v - pre_car.v;
    delta_y = 0.07883 * power(main_car.v,3) - 7.0115 * power(main_car.v,2) +206.8337 * main_car.v - 1968.4845;
    my_two_sqrt_accel_deceleration = 2 * sqrt(SVIDM_a_max * SVIDM_b_max);  
    S1 = main_car.v * SVIDM_T_safe;   
    S2 = main_car.v * delta_v / my_two_sqrt_accel_deceleration;   
    expected_x = SVIDM_d_safe + S1 + S2;
    a3 = SVIDM_a_max * (1 - power( main_car.v / SVIDM_v_max, 4) - power(expected_x / delta_y, 2));
end

%%ADV模型
function a4 = ADV_folow_vehicle_state_update(pre_car,main_car)
    deltv = main_car.v - pre_car.v;
    a4 = 0.002402 * power(deltv,3) - 0.004616 * power(deltv,2) - 0.08781 * deltv + 0.1086;
end


function [y,v] = update(a,main_car)

global time_step
    v = a * time_step + main_car.v;
    y = a * power(time_step,2)/2 + main_car.y + main_car.v * time_step;
end